#!/system/bin/sh
# Cirno Reclaim - late_start service.
# The daemon itself waits for sys.boot_completed and boot_delay.

MODDIR=${0%/*}
. "$MODDIR/bin/common.sh"

ensure_dirs
load_config

if [ ! -f "$CONFIG_FILE" ] && [ -f "$MODDIR/config.conf" ]; then
    cp -f "$MODDIR/config.conf" "$CONFIG_FILE"
    chmod 0600 "$CONFIG_FILE" 2>/dev/null
fi

# Remove a stale pid from a previous boot.
if [ -f "$PID_FILE" ]; then
    _pid=$(cat "$PID_FILE" 2>/dev/null)
    if ! is_number "$_pid" || [ ! -d "/proc/$_pid" ]; then
        rm -f "$PID_FILE"
    fi
fi

start_daemon
