#!/system/bin/sh
# Cirno Reclaim - installer script (Magisk / KernelSU / APatch).

SKIPUNZIP=0

if ! command -v ui_print >/dev/null 2>&1; then
    ui_print() { echo "$1"; }
fi

ui_print "*******************************"
ui_print "  Cirno 内存回收 / Cirno Reclaim"
ui_print "  配合 Cirno 冻结器使用的进程回收模块"
ui_print "*******************************"

mkdir -p /data/adb/cirno_reclaim/state 2>/dev/null
chmod 0700 /data/adb/cirno_reclaim /data/adb/cirno_reclaim/state 2>/dev/null

if [ ! -f /data/adb/cirno_reclaim/config.conf ]; then
    cp -f "$MODPATH/config.conf" /data/adb/cirno_reclaim/config.conf
    ui_print "- 已安装默认配置: /data/adb/cirno_reclaim/config.conf"
else
    ui_print "- 保留已有配置: /data/adb/cirno_reclaim/config.conf"
fi
chmod 0600 /data/adb/cirno_reclaim/config.conf 2>/dev/null

chown -R 0:0 "$MODPATH" 2>/dev/null
mkdir -p "$MODPATH/log" 2>/dev/null
chmod 0700 "$MODPATH/log" 2>/dev/null
chmod 0755 "$MODPATH" "$MODPATH/bin" "$MODPATH/webroot" 2>/dev/null
chmod 0755 "$MODPATH/service.sh" "$MODPATH/post-fs-data.sh" \
    "$MODPATH/customize.sh" "$MODPATH/uninstall.sh" "$MODPATH/action.sh" 2>/dev/null
chmod 0755 "$MODPATH/bin/"*.sh "$MODPATH/bin/cirno_pageout" 2>/dev/null
chmod 0644 "$MODPATH/module.prop" "$MODPATH/config.conf" \
    "$MODPATH/README.md" "$MODPATH/webroot/"* 2>/dev/null
chmod 0644 "$MODPATH/src/"* 2>/dev/null

if [ -d /data/misc/Cirno ]; then
    ui_print "- 检测到 Cirno 配置目录，兼容性正常"
else
    ui_print "- 未检测到 /data/misc/Cirno，请确认 Cirno 已启动过一次"
fi

ui_print "- 默认只在内存低于 800MB 时回收已冻结进程"
ui_print "- 配置文件: /data/adb/cirno_reclaim/config.conf"
ui_print "- KsuWebUI / KernelSU 模块页面可直接修改配置"
ui_print "- 重启后生效；也可执行 ctl.sh restart 立即启动"
