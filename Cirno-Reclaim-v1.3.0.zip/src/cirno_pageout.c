/*
 * cirno_pageout - page out a bounded amount of an Android app's anonymous
 * memory with process_madvise(MADV_PAGEOUT), without killing the process.
 *
 * Build (from this directory):
 *   zig cc -target aarch64-linux-musl -static -Os -s -o ../bin/cirno_pageout cirno_pageout.c
 *
 * Android 12+ GKI kernels generally provide process_madvise (5.10+), but
 * OEM kernels vary. The shell wrapper treats any failure as "unsupported"
 * and falls back to ActivityManager trim-memory.
 *
 * This is deliberately conservative: only private anonymous mappings are
 * considered, stacks/code/device/zygote/Dalvik/JIT mappings are skipped,
 * and the caller supplies a hard byte cap.
 */

#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <unistd.h>

#ifndef __NR_pidfd_open
#define __NR_pidfd_open 434
#endif
#ifndef __NR_process_madvise
#define __NR_process_madvise 440
#endif
#ifndef MADV_PAGEOUT
#define MADV_PAGEOUT 21
#endif

static int should_skip(const char *path, const char *perms)
{
    if (perms[3] != 'p')
        return 1;
    if (perms[1] != 'w' && perms[0] != 'r')
        return 1;
    if (path[0] == '\0')
        return 0;

    if (strstr(path, "[stack") || strstr(path, "[vdso") ||
        strstr(path, "[vvar") || strstr(path, "[vectors") ||
        strstr(path, "dalvik") || strstr(path, "jit") ||
        strstr(path, "zygote") || strstr(path, "gralloc") ||
        strstr(path, "gpu") || strstr(path, "kgsl") ||
        strstr(path, "/dev/") || strstr(path, "/system/") ||
        strstr(path, "/apex/") || strstr(path, "/vendor/") ||
        strstr(path, "/product/") || strstr(path, ".so") ||
        strstr(path, ".odex") || strstr(path, ".oat") ||
        strstr(path, ".art") || strstr(path, ".vdex"))
        return 1;

    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 2 || argc > 3) {
        fprintf(stderr, "usage: cirno_pageout <pid> [max_mb]\n");
        return 64;
    }

    char *end = NULL;
    long pid = strtol(argv[1], &end, 10);
    if (!end || *end != '\0' || pid <= 1)
        return 64;

    long max_mb = 256;
    if (argc == 3) {
        end = NULL;
        max_mb = strtol(argv[2], &end, 10);
        if (!end || *end != '\0' || max_mb <= 0 || max_mb > 4096)
            return 64;
    }
    unsigned long long cap = (unsigned long long)max_mb * 1024ULL * 1024ULL;
    unsigned long long done = 0;

    int pidfd = (int)syscall(__NR_pidfd_open, (pid_t)pid, 0);
    if (pidfd < 0) {
        fprintf(stderr, "pidfd_open: %s\n", strerror(errno));
        return 2;
    }

    char maps_path[64];
    snprintf(maps_path, sizeof(maps_path), "/proc/%ld/maps", pid);
    FILE *maps = fopen(maps_path, "r");
    if (!maps) {
        fprintf(stderr, "open maps: %s\n", strerror(errno));
        close(pidfd);
        return 2;
    }

    char line[4096];
    unsigned long long total = 0;
    while (done < cap && fgets(line, sizeof(line), maps)) {
        unsigned long start = 0, end_addr = 0;
        char perms[8] = {0};
        char path[2048] = {0};
        if (sscanf(line, "%lx-%lx %7s %*s %*s %*s %2047[^\n]",
                   &start, &end_addr, perms, path) < 3)
            continue;
        if (end_addr <= start)
            continue;

        char *p = path;
        while (*p == ' ' || *p == '\t')
            p++;
        if (should_skip(p, perms))
            continue;

        unsigned long long len = (unsigned long long)(end_addr - start);
        if (len == 0)
            continue;
        if (len > cap - done)
            len = cap - done;
        if (len > (1ULL << 30))
            len = 1ULL << 30;

        struct iovec iov;
        iov.iov_base = (void *)start;
        iov.iov_len = (size_t)len;

        long ret = syscall(__NR_process_madvise, pidfd, &iov, 1UL,
                           MADV_PAGEOUT, 0U);
        if (ret > 0) {
            done += (unsigned long long)ret;
            total += (unsigned long long)ret;
        } else if (ret < 0 && errno != EAGAIN && errno != ENOMEM &&
                   errno != EFAULT && errno != EINVAL) {
            /* Keep going on per-range errors; some VMAs reject hints. */
        }
    }

    fclose(maps);
    close(pidfd);
    printf("reclaimed_kb=%llu\n", total / 1024ULL);
    return total > 0 ? 0 : 3;
}
