#!/system/bin/sh
# Cirno Reclaim - uninstaller.

MODDIR=${0%/*}
. "$MODDIR/bin/common.sh"

stop_daemon 2>/dev/null

# Persistent config, state, pid and lock files.
rm -rf /data/adb/cirno_reclaim 2>/dev/null
[ -n "$DATA_DIR" ] && rm -rf "$DATA_DIR" 2>/dev/null

# The log lives inside the module so it disappears with the module, but
# remove it here too for manual uninstalls and for the current session.
[ -n "$MODDIR" ] && rm -rf "$MODDIR/log" 2>/dev/null
[ -n "$MODDIR" ] && rm -f "$MODDIR/nohup.out" 2>/dev/null
