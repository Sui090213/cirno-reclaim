#!/system/bin/sh
# Cirno Reclaim - post-fs-data: create persistent data and install defaults.

MODDIR=${0%/*}
. "$MODDIR/bin/common.sh"

ensure_dirs

if [ ! -f "$CONFIG_FILE" ] && [ -f "$MODDIR/config.conf" ]; then
    cp -f "$MODDIR/config.conf" "$CONFIG_FILE"
fi
chmod 0600 "$CONFIG_FILE" 2>/dev/null

# A pid file cannot survive a reboot.
rm -f "$PID_FILE"
