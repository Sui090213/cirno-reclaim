#!/system/bin/sh
# KernelSU action button: run one manual reclaim pass and show a short log.

MODDIR=${0%/*}
. "$MODDIR/bin/common.sh"

ensure_dirs
load_config

echo "Cirno Reclaim v$MODULE_VERSION"
echo "可用内存: $(get_mem_available_mb)MB / $(get_mem_total_mb)MB"
echo "触发阈值: ${MEM_LOW_MB}MB  目标: ${MEM_TARGET_MB}MB"
echo

sh "$MODDIR/bin/reclaim.sh" --manual

echo
echo "--- 最近日志 ---"
tail -n 8 "$LOG_FILE" 2>/dev/null
