#!/bin/sh
# Rebuild the arm64 helper on a PC with Zig:
#   zig cc -target aarch64-linux-musl -static -Os -s \
#       -o ../bin/cirno_pageout cirno_pageout.c
#
# The helper is optional. Without it, app_relief.sh still uses
# ActivityManager trim-memory, which is safe on every Android 12+ device.

set -e
cd "$(dirname "$0")"
zig cc -target aarch64-linux-musl -static -Os -s \
    -o ../bin/cirno_pageout cirno_pageout.c
