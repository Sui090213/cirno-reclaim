# 变更说明

## 这个 PR 做了什么

<!-- 一句话说明 -->

## 类型

- [ ] Bug 修复
- [ ] 新功能
- [ ] 参数/默认值调整
- [ ] 文档
- [ ] WebUI
- [ ] 原生 helper

## 怎么验证的

<!-- 真机型号 + 日志片段 / 静态检查结果 -->

```text

```

## 检查清单

- [ ] 只用了 POSIX sh（没有 `[[ ]]`、数组、`$'...'`、`+=`）
- [ ] `python3 tools/lint_sh.py .` 通过
- [ ] `node --check webroot/app.js` 通过
- [ ] 新增配置项同时更新了：`config.conf`、`bin/common.sh` 的 `cfg_defaults()` 与 `cfg_key_allowed()`、README 配置表
- [ ] 危险操作（kill / swapoff / drop_caches / rm）都有边界检查与降级
- [ ] 没有提交 `log/`、`state/`、`dist/`、`*.zip`

## 相关 issue

<!-- Fixes #123 -->
