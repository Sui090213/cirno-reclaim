(function () {
  'use strict';

  var MOD = '/data/adb/modules/cirno_reclaim';
  var state = {
    status: null,
    configLoaded: false,
    busy: false,
    hasRoot: false,
    refreshing: false,
    lastStatusKey: '',
    lastInteraction: 0
  };
  var toastTimer = 0;
  var confirmResolver = null;

  function $(id) {
    return document.getElementById(id);
  }

  function setText(id, text) {
    var el = $(id);
    if (el) el.textContent = text;
  }

  function setChecked(id, value) {
    var el = $(id);
    if (el) el.checked = value === 1 || value === true;
  }

  function checkedValue(id) {
    var el = $(id);
    return el && el.checked ? 1 : 0;
  }

  function isKsuAvailable() {
    return !!(window.ksu && typeof window.ksu.exec === 'function');
  }

  function detectModuleDir() {
    if (!window.ksu || typeof window.ksu.moduleInfo !== 'function') return;
    try {
      var raw = window.ksu.moduleInfo();
      var info = typeof raw === 'string' ? JSON.parse(raw) : raw;
      if (info && info.moduleDir) MOD = String(info.moduleDir);
    } catch (e) {
      /* keep default path */
    }
  }

  function execRoot(command, timeoutMs) {
    return new Promise(function (resolve, reject) {
      if (!isKsuAvailable()) {
        reject(new Error('当前页面没有 root 执行环境'));
        return;
      }

      var callbackName = '__cirno_reclaim_cb_' + Date.now() + '_' + Math.floor(Math.random() * 100000);
      var settled = false;
      var timer = setTimeout(function () {
        if (settled) return;
        settled = true;
        try { delete window[callbackName]; } catch (e) { window[callbackName] = undefined; }
        reject(new Error('root 命令超时'));
      }, timeoutMs || 45000);

      window[callbackName] = function (errno, stdout, stderr) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        try { delete window[callbackName]; } catch (e) { window[callbackName] = undefined; }
        resolve({
          errno: Number(errno) || 0,
          stdout: stdout || '',
          stderr: stderr || ''
        });
      };

      try {
        if (window.ksu.exec.length === 2) {
          window.ksu.exec(command, callbackName);
        } else {
          window.ksu.exec(command, '{}', callbackName);
        }
      } catch (firstError) {
        try {
          window.ksu.exec(command, callbackName);
        } catch (secondError) {
          settled = true;
          clearTimeout(timer);
          try { delete window[callbackName]; } catch (e) { window[callbackName] = undefined; }
          reject(secondError || firstError);
        }
      }
    });
  }

  function ctl(action, timeoutMs) {
    var command = "sh '" + MOD + "/bin/ctl.sh' " + action;
    return execRoot(command, timeoutMs).then(function (result) {
      if (result.errno !== 0) {
        var message = (result.stderr || result.stdout || 'root 命令执行失败').trim();
        throw new Error(message);
      }
      return result.stdout.trim();
    });
  }

  function parseJson(text) {
    try {
      return JSON.parse(text);
    } catch (e) {
      var start = text.indexOf('{');
      if (start >= 0) {
        return JSON.parse(text.slice(start));
      }
      throw e;
    }
  }

  function ctlJson(action, timeoutMs) {
    return ctl(action, timeoutMs).then(parseJson);
  }

  function formatMb(value) {
    var n = Number(value) || 0;
    if (n >= 1024) {
      return (n / 1024).toFixed(n >= 10240 ? 0 : 1) + ' GB';
    }
    return Math.round(n) + ' MB';
  }

  function mbParts(value) {
    var n = Number(value) || 0;
    if (n >= 1024) {
      return { value: (n / 1024).toFixed(n >= 10240 ? 0 : 1), unit: 'GB' };
    }
    return { value: String(Math.round(n)), unit: 'MB' };
  }

  function formatTime(epoch) {
    var n = Number(epoch) || 0;
    if (!n) return '尚未运行';
    try {
      return new Date(n * 1000).toLocaleString('zh-CN', {
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
      });
    } catch (e) {
      return '--';
    }
  }

  function formatAge(seconds) {
    var s = Math.max(0, Number(seconds) || 0);
    if (s < 60) return Math.round(s) + ' 秒';
    if (s < 3600) return Math.floor(s / 60) + ' 分钟';
    return (s / 3600).toFixed(1) + ' 小时';
  }

  function toast(message, bad) {
    var el = $('toast');
    if (!el) return;
    clearTimeout(toastTimer);
    el.textContent = message;
    el.className = 'toast show' + (bad ? ' bad' : '');
    toastTimer = setTimeout(function () {
      el.className = 'toast';
    }, 3600);
  }

  function askConfirm(message) {
    return new Promise(function (resolve) {
      $('confirmText').textContent = message;
      $('confirmModal').hidden = false;
      confirmResolver = resolve;
    });
  }

  function settleConfirm(value) {
    if (!confirmResolver) return;
    var resolve = confirmResolver;
    confirmResolver = null;
    $('confirmModal').hidden = true;
    resolve(value);
  }

  function setBusy(busy) {
    state.busy = busy;
    var bar = $('busyBar');
    if (bar) bar.hidden = !busy;
    var buttons = document.querySelectorAll('.btn');
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].disabled = busy;
    }
  }

  function renderStatus(data) {
    state.status = data;
    var mem = data.mem || {};
    var stats = data.stats || {};
    var config = data.config || {};
    var avail = Number(mem.available_mb) || 0;
    var total = Number(mem.total_mb) || 0;

    var parts = mbParts(avail);
    setText('availValue', parts.value);
    setText('availUnit', parts.unit);
    setText('totalValue', formatMb(total));
    setText('swapValue', formatMb(mem.swap_free_mb));
    setText('totalReclaim', formatMb(stats.total_reclaim_mb));
    setText('totalKilled', String(Number(stats.total_killed) || 0));
    setText('lastReclaim', formatMb(stats.last_reclaim_mb));
    setText('lastAfter', formatMb(stats.last_after_mb));
    setText('lastBefore', stats.last_run ? '回收前 ' + formatMb(stats.last_before_mb) : '--');
    setText('versionText', 'v' + (data.version || '1.3.0'));

    if (stats.last_run) {
      var lastText = formatTime(stats.last_run);
      if (!Number(stats.last_killed)) lastText += ' · 无候选';
      setText('lastPass', lastText);
    } else {
      setText('lastPass', '尚未运行');
    }

    var pct = total > 0 ? Math.max(0, Math.min(100, avail / total * 100)) : 0;
    var bar = $('memBar');
    if (bar) bar.style.width = pct.toFixed(2) + '%';

    var target = Number(config.mem_target_mb) || 0;
    var mark = $('memTargetMark');
    if (mark) {
      mark.style.left = total > 0 && target > 0
        ? Math.max(0, Math.min(100, target / total * 100)).toFixed(2) + '%'
        : '0%';
      mark.style.display = total > 0 && target > 0 ? 'block' : 'none';
    }

    setText('targetHint', '目标 ' + formatMb(target));
    setText('totalHint', '总计 ' + formatMb(total));

    var low = Number(config.mem_low_mb) || 0;
    var badge = $('pressureBadge');
    if (badge) {
      if (low <= 0) {
        badge.className = 'hero-badge';
        badge.textContent = '自动阈值关闭';
      } else if (avail < low * 0.5) {
        badge.className = 'hero-badge bad';
        badge.textContent = '内存紧张';
      } else if (avail < low) {
        badge.className = 'hero-badge warn';
        badge.textContent = '低于阈值';
      } else {
        badge.className = 'hero-badge';
        badge.textContent = '内存充足';
      }
    }

    var pill = $('daemonPill');
    if (pill) {
      if (data.running) {
        pill.className = 'pill pill-good';
        setText('daemonText', data.enabled ? '守护运行中' : '已暂停');
      } else {
        pill.className = 'pill pill-bad';
        setText('daemonText', '守护未运行');
      }
    }

    if (!state.configLoaded && config) {
      fillForm(config);
      state.configLoaded = true;
    }
  }

  function fillForm(config) {
    setText('versionText', 'v' + ((state.status && state.status.version) || '1.3.0'));
    var keysNumber = [
      'interval', 'boot_delay', 'mem_low_mb', 'mem_target_mb',
      'high_pss_mb', 'high_pss_interval',
      'app_pss_mb', 'app_reclaim_interval', 'app_reclaim_cooldown', 'app_pageout_max_mb',
      'max_kills_per_run', 'max_kills_per_hour', 'cooldown_sec',
      'min_process_mb', 'min_frozen_min', 'min_oom_score_adj',
      'drop_caches_cooldown', 'log_max_kb'
    ];
    keysNumber.forEach(function (key) {
      var el = $(key);
      if (el && config[key] !== undefined) el.value = String(config[key]);
    });

    setChecked('enable', config.enable);
    setChecked('dry_run', config.dry_run);
    setChecked('only_frozen', config.only_frozen);
    setChecked('protect_foreground', config.protect_foreground);
    setChecked('screen_off_only', config.screen_off_only);
    setChecked('drop_caches', config.drop_caches);
    setChecked('app_reclaim', config.app_reclaim);
    setChecked('app_pageout', config.app_pageout);
    setChecked('app_proc_reclaim', config.app_proc_reclaim);
    var trim = $('app_trim_level');
    if (trim) trim.value = config.app_trim_level || 'RUNNING_LOW';
    setText('versionText', 'v' + ((state.status && state.status.version) || '1.3.0'));

    var mode = $('kill_mode');
    if (mode) mode.value = config.kill_mode === 'am' ? 'am' : 'pid';

    var include = $('include_packages');
    if (include) {
      include.value = String(config.include_packages || '')
        .split(';').map(function (s) { return s.trim(); }).filter(Boolean).join('\n');
    }
    var exclude = $('exclude_packages');
    if (exclude) {
      exclude.value = String(config.exclude_packages || '')
        .split(';').map(function (s) { return s.trim(); }).filter(Boolean).join('\n');
    }
  }

  function readNumber(id, min, max, label) {
    var el = $(id);
    var raw = el ? String(el.value).trim() : '';
    var n = Number(raw);
    if (!raw || !isFinite(n) || Math.floor(n) !== n || n < min || n > max) {
      throw new Error(label + ' 需要是 ' + min + '–' + max + ' 的整数');
    }
    return n;
  }

  function readList(id, label) {
    var el = $(id);
    var raw = el ? el.value : '';
    var list = raw.split(/[\n;,]+/).map(function (s) { return s.trim(); }).filter(Boolean);
    for (var i = 0; i < list.length; i++) {
      if (!/^[A-Za-z0-9._*?-]+$/.test(list[i])) {
        throw new Error(label + ' 中包含不支持的字符: ' + list[i]);
      }
    }
    return list.join(';');
  }

  function collectForm() {
    var allowSystem = 0;
    if (state.status && state.status.config && Number(state.status.config.allow_system_uid) === 1) {
      allowSystem = 1;
    }
    var low = readNumber('mem_low_mb', 0, 1048576, '低内存阈值');
    var target = readNumber('mem_target_mb', 0, 1048576, '目标可用内存');
    if (target <= low) {
      throw new Error('目标可用内存需要大于低内存触发值');
    }
    return {
      enable: checkedValue('enable'),
      dry_run: checkedValue('dry_run'),
      interval: readNumber('interval', 10, 3600, '检查周期'),
      boot_delay: readNumber('boot_delay', 0, 7200, '开机等待'),
      mem_low_mb: low,
      mem_target_mb: target,
      high_pss_mb: readNumber('high_pss_mb', 0, 1048576, '单进程高内存阈值'),
      high_pss_interval: readNumber('high_pss_interval', 30, 3600, '高内存检查周期'),
      app_reclaim: checkedValue('app_reclaim'),
      app_pss_mb: readNumber('app_pss_mb', 0, 1048576, '应用总 PSS 阈值'),
      app_reclaim_interval: readNumber('app_reclaim_interval', 30, 600, '前台检查周期'),
      app_reclaim_cooldown: readNumber('app_reclaim_cooldown', 30, 3600, '前台舒缓冷却'),
      app_trim_level: ($('app_trim_level') && $('app_trim_level').value) || 'RUNNING_LOW',
      app_pageout: checkedValue('app_pageout'),
      app_pageout_max_mb: readNumber('app_pageout_max_mb', 16, 1024, '单次页换出上限'),
      app_proc_reclaim: checkedValue('app_proc_reclaim'),
      max_kills_per_run: readNumber('max_kills_per_run', 0, 50, '单次最多回收'),
      max_kills_per_hour: readNumber('max_kills_per_hour', 0, 200, '每小时最多回收'),
      cooldown_sec: readNumber('cooldown_sec', 0, 86400, '回收冷却'),
      min_process_mb: readNumber('min_process_mb', 1, 4096, '最小进程 PSS'),
      min_frozen_min: readNumber('min_frozen_min', 0, 10080, '冻结冷却'),
      min_oom_score_adj: readNumber('min_oom_score_adj', 0, 1000, '最低 oom_score_adj'),
      only_frozen: checkedValue('only_frozen'),
      kill_mode: ($('kill_mode') && $('kill_mode').value) === 'am' ? 'am' : 'pid',
      protect_foreground: checkedValue('protect_foreground'),
      screen_off_only: checkedValue('screen_off_only'),
      drop_caches: checkedValue('drop_caches'),
      drop_caches_cooldown: readNumber('drop_caches_cooldown', 0, 86400, '清缓存冷却'),
      allow_system_uid: allowSystem,
      include_packages: readList('include_packages', '只回收名单'),
      exclude_packages: readList('exclude_packages', '保护名单'),
      log_max_kb: readNumber('log_max_kb', 16, 4096, '日志上限')
    };
  }

  var CONFIG_COMPARE_KEYS = [
    'enable', 'dry_run', 'interval', 'boot_delay', 'mem_low_mb', 'mem_target_mb',
    'high_pss_mb', 'high_pss_interval',
    'app_reclaim', 'app_pss_mb', 'app_reclaim_interval', 'app_reclaim_cooldown',
    'app_trim_level', 'app_pageout', 'app_pageout_max_mb', 'app_proc_reclaim',
    'max_kills_per_run', 'max_kills_per_hour',
    'cooldown_sec', 'min_process_mb', 'min_frozen_min', 'min_oom_score_adj',
    'only_frozen', 'kill_mode', 'protect_foreground', 'screen_off_only',
    'drop_caches', 'drop_caches_cooldown', 'allow_system_uid',
    'include_packages', 'exclude_packages', 'log_max_kb'
  ];

  function configMatches(actual, expected) {
    if (!actual || !expected) return false;
    for (var i = 0; i < CONFIG_COMPARE_KEYS.length; i++) {
      var key = CONFIG_COMPARE_KEYS[i];
      if (String(actual[key]) !== String(expected[key])) return false;
    }
    return true;
  }

  function toBase64(text) {
    var bytes = new TextEncoder().encode(text);
    var binary = '';
    var chunk = 0x8000;
    for (var i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return btoa(binary);
  }

  function refresh() {
    if (!state.hasRoot) return Promise.resolve();
    if (state.refreshing) return Promise.resolve();
    state.refreshing = true;
    return ctlJson('status').then(function (data) {
      if (!data.ok) throw new Error('状态读取失败');
      var key = JSON.stringify(data);
      if (key === state.lastStatusKey && state.configLoaded) {
        return;
      }
      state.lastStatusKey = key;
      renderStatus(data);
    }).catch(function (error) {
      var pill = $('daemonPill');
      if (pill) {
        pill.className = 'pill pill-bad';
        setText('daemonText', '连接失败');
      }
      if (!state.status) toast(error.message || '无法读取状态', true);
    }).then(function () {
      state.refreshing = false;
    });
  }

  function saveConfig() {
    if (state.busy) return;
    if (!state.configLoaded) {
      toast('状态尚未加载完成，请稍后再试', true);
      return;
    }
    var config;
    try {
      config = collectForm();
    } catch (error) {
      toast(error.message, true);
      return;
    }

    var text = Object.keys(config).map(function (key) {
      return key + '=' + config[key];
    }).join('\n') + '\n';
    var payload = toBase64(text);

    setBusy(true);
    ctl('save ' + payload, 30000).then(function (out) {
      var data = parseJson(out);
      if (!data.ok) throw new Error(data.error || '保存失败');
      // Read the config back from disk through ctl.sh. Do not trust the
      // write alone: a read-only /data/adb or a failed rename used to show
      // "saved" while the next page load returned the old defaults.
      return ctlJson('status', 30000);
    }).then(function (status) {
      if (!status.ok) throw new Error('配置回读失败');
      // Values may be normalized/clamped by load_config (for example a
      // target below the trigger point). That is not a write failure, so do
      // not show a scary read-back error. ctl.sh already verified the file
      // was actually written and renamed.
      if (!configMatches(status.config, config)) {
        console.warn('config normalized after save');
      }
      state.status = status;
      renderStatus(status);
      toast('配置已保存');
    }).catch(function (error) {
      toast(error.message || '保存失败', true);
    }).then(function () {
      setBusy(false);
    });
  }

  function renderCandidates(data) {
    var card = $('candidatesCard');
    var body = $('candidateRows');
    var list = data.candidates || [];
    var ready = list.filter(function (item) { return item.eligible; }).length;

    setText('scanInfo', '当前可用 ' + formatMb(data.mem_available_mb) +
      '，共 ' + list.length + ' 个候选，' + ready + ' 个已过冻结冷却。');
    body.innerHTML = '';

    if (!list.length) {
      var emptyRow = document.createElement('tr');
      var emptyCell = document.createElement('td');
      emptyCell.colSpan = 5;
      emptyCell.className = 'empty';
      emptyCell.textContent = '没有符合条件的已冻结进程。确认 Cirno 正在冻结后台应用，或等待冻结冷却结束。';
      emptyRow.appendChild(emptyCell);
      body.appendChild(emptyRow);
    } else {
      list.forEach(function (item) {
        var tr = document.createElement('tr');

        var pkg = document.createElement('td');
        pkg.className = 'pkg';
        pkg.textContent = item.package || '--';
        pkg.title = item.package || '';
        tr.appendChild(pkg);

        var pid = document.createElement('td');
        pid.textContent = String(item.pid);
        tr.appendChild(pid);

        var pss = document.createElement('td');
        pss.textContent = formatMb(item.pss_mb);
        tr.appendChild(pss);

        var age = document.createElement('td');
        age.textContent = formatAge(item.age_sec);
        tr.appendChild(age);

        var status = document.createElement('td');
        var chip = document.createElement('span');
        chip.className = 'chip ' + (item.eligible ? 'chip-ready' : 'chip-wait');
        chip.textContent = item.eligible ? '可回收' : '冷却中';
        status.appendChild(chip);
        tr.appendChild(status);

        body.appendChild(tr);
      });
    }

    card.hidden = false;
    card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function scan() {
    if (state.busy) return;
    setBusy(true);
    ctlJson('scan').then(function (data) {
      if (!data.ok) throw new Error(data.error || '扫描失败');
      renderCandidates(data);
      toast(data.candidates.length ? '扫描完成' : '当前没有候选进程');
    }).catch(function (error) {
      toast(error.message || '扫描失败', true);
    }).then(function () {
      setBusy(false);
    });
  }

  function runNow() {
    if (state.busy) return;
    askConfirm('确定现在执行一次回收吗？\n\n只会处理已冻结、缓存级、通过白名单过滤的进程。').then(function (ok) {
      if (!ok) return;
      setBusy(true);
      ctlJson('run', 120000).then(function (data) {
        if (!data.ok) throw new Error(data.error || '执行失败');
        var suffix = data.dry_run ? '（演练模式，未真正结束进程）' : '';
        toast('完成：释放 ' + formatMb(data.reclaimed_mb) + '，处理 ' + data.killed + ' 个进程' + suffix);
        return refresh();
      }).catch(function (error) {
        toast(error.message || '执行失败', true);
      }).then(function () {
        setBusy(false);
      });
    });
  }

  function relieveApp() {
    if (state.busy) return;
    setBusy(true);
    ctlJson('apprelief', 60000).then(function (data) {
      if (!data.ok) throw new Error(data.error || '前台舒缓失败');
      toast('已对当前前台应用执行舒缓，详见运行日志');
      return refresh();
    }).catch(function (error) {
      toast(error.message || '前台舒缓失败', true);
    }).then(function () {
      setBusy(false);
    });
  }

  function restartDaemon() {
    if (state.busy) return;
    setBusy(true);
    ctlJson('restart', 30000).then(function (data) {
      if (!data.ok) throw new Error('守护启动失败');
      toast('守护进程已重启');
      return refresh();
    }).catch(function (error) {
      toast(error.message || '重启失败', true);
    }).then(function () {
      setBusy(false);
    });
  }

  function showLog() {
    if (state.busy) return;
    setBusy(true);
    ctl('log', 30000).then(function (text) {
      $('logContent').textContent = text || '暂无日志。';
      $('logModal').hidden = false;
    }).catch(function (error) {
      toast(error.message || '读取日志失败', true);
    }).then(function () {
      setBusy(false);
    });
  }

  function init() {
    detectModuleDir();
    state.hasRoot = isKsuAvailable();

    if (!state.hasRoot) {
      $('unsupported').hidden = false;
      var pill = $('daemonPill');
      if (pill) {
        pill.className = 'pill pill-bad';
        setText('daemonText', '无 root 环境');
      }
      setBusy(true);
      $('busyBar').hidden = true;
      return;
    }

    $('saveBtn').addEventListener('click', saveConfig);
    $('runBtn').addEventListener('click', runNow);
    $('appReliefBtn').addEventListener('click', relieveApp);
    $('scanBtn').addEventListener('click', scan);
    $('restartBtn').addEventListener('click', restartDaemon);
    $('logBtn').addEventListener('click', showLog);
    $('refreshBtn').addEventListener('click', function () { refresh(); });
    $('closeLog').addEventListener('click', function () { $('logModal').hidden = true; });
    $('closeCandidates').addEventListener('click', function () { $('candidatesCard').hidden = true; });

    $('confirmOk').addEventListener('click', function () { settleConfirm(true); });
    $('confirmCancel').addEventListener('click', function () { settleConfirm(false); });
    $('confirmClose').addEventListener('click', function () { settleConfirm(false); });

    $('logModal').addEventListener('click', function (event) {
      if (event.target === $('logModal')) $('logModal').hidden = true;
    });
    $('confirmModal').addEventListener('click', function (event) {
      if (event.target === $('confirmModal')) settleConfirm(false);
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        $('logModal').hidden = true;
        $('candidatesCard').hidden = true;
        settleConfirm(false);
      }
    });

    document.addEventListener('pointerdown', function () {
      state.lastInteraction = Date.now();
    }, true);

    // Let the first paint finish before opening a root shell. The old
    // immediate call competed with WebView layout and made the page feel
    // frozen for the first tap.
    setTimeout(function () { refresh(); }, 350);
    setInterval(function () {
      if (document.hidden) return;
      if (Date.now() - state.lastInteraction < 8000) return;
      refresh();
    }, 15000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
